export class Employee {
  name: string;
  age: number;
  location: string;
  email: string;
  designation: string;
  phoneNumber: number;
}
